﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CRUD_05.BLL.System;
using CRUD_05.CRUD.System;
using CRUD_05.MODEL.System;

namespace CRUD_05 {
    public partial class TelaPrincipal : Form {
        public TelaPrincipal() {
            InitializeComponent();
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Listar();
        }
        public void LimparCampos() {
            txtMatricula.Clear();
            txtNome.Clear();
            cmbCursos.SelectedIndex = -1;
            cmIdCurso.SelectedIndex = -1;
            txtNome.BackColor = Color.White;
            cmIdCurso.BackColor = Color.White;
            cmbCursos.BackColor = Color.White;
           
        }
        
        private void Salvar(Aluno a, Curso curso)
            {
            Crud crud = new Crud();

            if ((txtNome.Text.Trim()==string.Empty)||(cmbCursos.Text.Trim()==string.Empty)||(cmIdCurso.Text.Trim()==string.Empty)) {
                MessageBox.Show("Campos obrigatórios a serem preenchidos!","Alerta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else {
                a.Nome = txtNome.Text;
                curso.Nome_disc = cmbCursos.Text;
                a.Id_curso = int.Parse(cmIdCurso.Text);
                crud.CadastrarAluno(a);
                crud.CadastrarCurso(curso);
                  Listar();
            }
          
            
        }
        private void Listar() {
            AlunoBLL pessoaBLL = new AlunoBLL();
            dg_dados.DataSource = pessoaBLL.Listar();

            dg_dados.Columns[0].HeaderText = "MATRICULA";
            dg_dados.Columns[1].HeaderText = "ALUNO";
            dg_dados.Columns[2].HeaderText = "DISCIPLINA";
            dg_dados.Columns[0].Width = 80;
            dg_dados.Columns[1].Width = 300;
            dg_dados.Columns[2].Width = 200;
            LimparCampos();
           
        }

        private void bttSalvar_Click(object sender, EventArgs e) {
            Aluno aluno = new Aluno();
            Curso curso = new Curso();
            Salvar(aluno, curso);
        }

        private void dg_dados_CellDoubleClick(object sender, DataGridViewCellEventArgs e) {
            txtMatricula.Text = dg_dados.CurrentRow.Cells[0].Value.ToString();
            txtNome.Text = dg_dados.CurrentRow.Cells[1].Value.ToString();
            cmIdCurso.Text = dg_dados.CurrentRow.Cells[2].Value.ToString();
            //cmbCursos.Text = dg_dados.CurrentRow.Cells[5].Value.ToString();

          
            

        }

        private void Editar(Aluno aluno) {
            Crud crud = new Crud();
            Curso curso = new Curso();
            AlunoBLL pessoaBLL = new AlunoBLL();

            if((txtNome.Text.Trim()==string.Empty)||(cmbCursos.Text.Trim() == string.Empty)||(cmIdCurso.Text.Trim()==string.Empty)) {
                MessageBox.Show("Campos Obrigatórios a serem preenchidos!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNome.BackColor = Color.Yellow;
                txtMatricula.BackColor = Color.Yellow;
                cmbCursos.BackColor = Color.Yellow;
                cmIdCurso.BackColor = Color.Yellow;
               

            }
            else {
                aluno.Id_curso = int.Parse(cmIdCurso.Text);
                aluno.Nome = txtNome.Text.ToUpper();
                curso.Nome_disc = cmbCursos.Text.ToUpper();
                curso.Id_curso = int.Parse(cmIdCurso.Text);
                aluno.Matricula = int.Parse(txtMatricula.Text);
                
                pessoaBLL.Editar(aluno);
                MessageBox.Show("Dados alterados com Sucesso!");
                Listar();
                LimparCampos();
            }
        }
        private void bttEditar_Click(object sender, EventArgs e) {
            Aluno aluno = new Aluno();
            Editar(aluno);
        }

        private void Excluir(Aluno aluno) {
            Crud crud = new Crud();

            if (txtMatricula.Text.Trim() == string.Empty) {
                MessageBox.Show("Selecione um aluno para excluir!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else if ((MessageBox.Show("Deseja realmente excluir?", "Alerta", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.No)) {

            }
            else {
                aluno.Matricula = int.Parse(txtMatricula.Text);
                crud.Excluir(aluno);
                MessageBox.Show("Aluno excluído com sucesso!!");
                Listar();
            }
        }

        private void bttExcluir_Click(object sender, EventArgs e) {
            Aluno a = new Aluno();
            Excluir(a);
            LimparCampos();
        }

        private void buttCancelar_Click(object sender, EventArgs e) {
            LimparCampos();
        }
    }
}
